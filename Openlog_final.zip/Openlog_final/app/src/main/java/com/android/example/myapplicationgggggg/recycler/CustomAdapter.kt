package com.android.example.basicapp.recycler
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.navigation.findNavController
import androidx.recyclerview.widget.AsyncListDiffer
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.RecyclerView
import com.android.example.myapplicationgggggg.FrontpageFragmentDirections
import com.android.example.myapplicationgggggg.dataaccesslayer.LogEntity
import com.android.example.myapplicationgggggg.databinding.ItemContactBinding


/**
 * Made by Tobias Borgstrøm s184810
 * Inspiration from https://guides.codepath.com/android/using-the-recyclerview
 */
class CustomAdapter() :
    RecyclerView.Adapter<CustomAdapter.LogViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): LogViewHolder {
        val innerbinding =
            ItemContactBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return LogViewHolder(innerbinding)
    }

    override fun onBindViewHolder(holder: CustomAdapter.LogViewHolder, position: Int) {
        val current = differ.currentList[position]
        holder.bindView(current)

    }

    private val differCallBack = object : DiffUtil.ItemCallback<LogEntity>() {
        override fun areItemsTheSame(oldItem: LogEntity, newItem: LogEntity): Boolean {
            return oldItem.contentEquals(newItem)
        }

        override fun areContentsTheSame(oldItem: LogEntity, newItem: LogEntity): Boolean {
            return oldItem.contentEquals(newItem)
        }
    }

    val differ = AsyncListDiffer(this, differCallBack)
    inner class LogViewHolder(private val binding: ItemContactBinding) :
        RecyclerView.ViewHolder(binding.root) {

        fun bindView(logItem: LogEntity) {
            binding.apply {

                logName.text = logItem.name

                val addButton = binding.imageButton
                val titleButton = binding.logName
                val dataButton = binding.dataText

                val mDataButtonClickListener: View.OnClickListener = View.OnClickListener {
                    val action = FrontpageFragmentDirections.actionFrontpageFragmentToOverviewFragment(
                        logItem.name,
                        logItem.id,
                        logItem.measure,
                        logItem
                    )
                    itemView.findNavController().navigate(action)
                }

                val addButtonClickListener: View.OnClickListener = View.OnClickListener {
                    val action = FrontpageFragmentDirections.actionFrontpageFragmentToFragmentSingle(
                        logItem.id,
                        logItem.name,
                        logItem.measure,
                        logItem.inLogCycle
                    )
                    itemView.findNavController().navigate(action)
                }

                titleButton.text = logItem.name
                addButton.setOnClickListener(addButtonClickListener)
                dataButton.setOnClickListener(mDataButtonClickListener)
            }
        }
    }

    override fun getItemCount(): Int {
        return  differ.currentList.size
    }

}