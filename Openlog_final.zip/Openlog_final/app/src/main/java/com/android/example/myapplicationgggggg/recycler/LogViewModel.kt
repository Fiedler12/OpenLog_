package com.android.example.myapplicationgggggg.recycler

import androidx.lifecycle.LiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.android.example.myapplicationgggggg.dataaccesslayer.LogDao
import com.android.example.myapplicationgggggg.dataaccesslayer.LogEntity
import kotlinx.coroutines.launch
import java.lang.IllegalArgumentException

/**
 * Made by Oliver Fiedler s204523
 */
class LogViewModel(private val logDao: LogDao) : ViewModel() {

    val allLogs: LiveData<List<LogEntity>> = logDao.getLogs()

    private fun insertLog(logEntity: LogEntity) {
        viewModelScope.launch { logDao.insert(logEntity) }
    }

    fun addNewItem(logName: String, logMeasure: String, addToCycle: Boolean) {
        val newLog = getNewLogEntry(logName, logMeasure, addToCycle)
        insertLog(newLog)
    }

    private fun getNewLogEntry (logName: String, logMeasure: String, addToCycle: Boolean): LogEntity {
        val list: List<LogEntity>? = allLogs.value
        var order : Int? = null
        if (list != null) {
            order = list.size + 1
        } else {
            order = 1
        }
        return LogEntity(
            0,
            logName,
            logMeasure,
            addToCycle,
            order)}
    private fun deleteLog(logEntity: LogEntity) {
     viewModelScope.launch { logDao.delete(logEntity) }
    }

    fun removeLog(logEntity: LogEntity) {
        deleteLog(logEntity)
    }

    fun updateLog(logEntity: LogEntity) {
        updateSingleLog(logEntity)
    }

    private fun updateSingleLog(logEntity: LogEntity) {
     viewModelScope.launch { logDao.update(logEntity) }
    }
}

class LogViewModelFactory(private val logDao: LogDao) : ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>) : T {
        if (modelClass.isAssignableFrom(LogViewModel::class.java)) {
            @Suppress("UNCHECKED_CAST")
            return LogViewModel(logDao) as T
        }
        throw IllegalArgumentException("unknown ViewModel class")
    }
}