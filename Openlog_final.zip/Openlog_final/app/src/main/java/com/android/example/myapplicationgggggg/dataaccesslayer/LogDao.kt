package com.android.example.myapplicationgggggg.dataaccesslayer

import androidx.lifecycle.LiveData
import androidx.room.*

/**
 * Made by Oliver Fiedler s204523
 */
@Dao
interface LogDao {

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insert(logEntity: LogEntity)

    @Update
    suspend fun update(logEntity: LogEntity)

    @Delete
    suspend fun delete(logEntity: LogEntity)

    @Query("SELECT * from Log ORDER by `order` ASC")
    fun getLogs(): LiveData<List<LogEntity>>

}