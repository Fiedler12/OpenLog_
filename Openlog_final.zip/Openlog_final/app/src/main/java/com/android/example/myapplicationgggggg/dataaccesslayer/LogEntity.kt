package com.android.example.myapplicationgggggg.dataaccesslayer

import android.os.Parcelable
import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey
import kotlinx.android.parcel.Parcelize

/**
 * Made by Oliver Fiedler s204523
 */
@Parcelize
@Entity(tableName = "Log")
data class LogEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Int = 0,
    @ColumnInfo(name = "name")
    val name: String,
    @ColumnInfo(name = "measure")
    val measure: String,
    @ColumnInfo(name = "inLogCycle")
    var inLogCycle: Boolean,
    @ColumnInfo(name = "order")
    var order: Int
) : Parcelable {
    fun contentEquals(newItem: LogEntity): Boolean {
        return this.id == newItem.id
    }
}