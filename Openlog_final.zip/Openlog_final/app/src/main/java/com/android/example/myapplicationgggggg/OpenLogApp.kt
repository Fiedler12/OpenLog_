package com.android.example.myapplicationgggggg

import android.app.Application
import com.android.example.myapplicationgggggg.dataaccesslayer.LogDatabase
import com.android.example.myapplicationgggggg.dataaccesslayer.ValueDatabase

/**
 * Made by Oliver Fiedler s204523
 */
class OpenLogApp : Application() {
    val logDatabase: LogDatabase by lazy { LogDatabase.getDatabase(this) }
    val valueDatabase: ValueDatabase by lazy { ValueDatabase.getDatabase(this)}
}