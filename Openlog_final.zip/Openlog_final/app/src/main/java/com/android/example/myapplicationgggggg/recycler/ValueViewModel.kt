package com.android.example.myapplicationgggggg.recycler

import androidx.lifecycle.LiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.android.example.myapplicationgggggg.dataaccesslayer.ValueDao
import com.android.example.myapplicationgggggg.dataaccesslayer.ValueEntity
import kotlinx.coroutines.launch
import java.lang.IllegalArgumentException
import java.text.SimpleDateFormat
import java.util.*

class ValueViewModel(private val valueDao: ValueDao): ViewModel() {

    fun getValues(id: Int): LiveData<List<ValueEntity>> {
        val allValues: LiveData<List<ValueEntity>> = valueDao.getValues(id)
        return allValues
    }

    fun deleteSingleValue(valueEntity: ValueEntity) {
        deleteValue(valueEntity)
    }

    fun updateValue(valueEntity: ValueEntity) {
        updateSingleValue(valueEntity)
    }

    private fun updateSingleValue(valueEntity: ValueEntity) {
        viewModelScope.launch {
            valueDao.update(valueEntity)
        }
    }

    private fun deleteValue(valueEntity: ValueEntity) {
        viewModelScope.launch {
            valueDao.delete(valueEntity) }
    }

    private fun insertValue(valueEntity: ValueEntity) {
        viewModelScope.launch {
            valueDao.insert(valueEntity) }
    }

    fun addNewValue(value: Int, logId: Int) {
        val newValue = getNewValue(value, logId)
        insertValue(newValue)
    }

    private fun getNewValue(value: Int, logId: Int) : ValueEntity {
        val date: Date = Calendar.getInstance().time
        val formatter1 = SimpleDateFormat("dd-MM-yyyy")
        val formatter2 = SimpleDateFormat("HH:mm")
        val formattedDate = formatter1.format(date)
        val formattedTime = formatter2.format(date)
        return ValueEntity(
            0,
            logId,
            value,
            formattedDate.toString(),
            formattedTime.toString())
    }
}

class ValueViewModelFactory(private val valueDao: ValueDao) : ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>) : T {
        if (modelClass.isAssignableFrom(ValueViewModel::class.java)) {
            @Suppress("UNCHECKED_CAST")
            return ValueViewModel(valueDao) as T
        }
        throw IllegalArgumentException("uknown ViewModel class")
    }
}