package com.android.example.myapplicationgggggg.recycler

import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView

import android.view.LayoutInflater
import androidx.recyclerview.widget.AsyncListDiffer
import androidx.recyclerview.widget.DiffUtil
import com.android.example.myapplicationgggggg.dataaccesslayer.LogEntity
import com.android.example.myapplicationgggggg.databinding.LogCycleItemBinding

class LogCycleAdapter() :
    RecyclerView.Adapter<LogCycleAdapter.LogCycleViewHolder>() {

    val viewHolderList : MutableList<LogCycleViewHolder> = mutableListOf()
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): LogCycleViewHolder {
        val binding =
            LogCycleItemBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return LogCycleViewHolder(binding)
    }

    override fun onBindViewHolder(holder: LogCycleViewHolder, position: Int) {
        val current = differ.currentList[position]
        holder.bindView(current)
        viewHolderList.add(holder)
    }

    private val differCallBack = object : DiffUtil.ItemCallback<LogEntity>() {
        override fun areItemsTheSame(oldItem: LogEntity, newItem: LogEntity): Boolean {
            return oldItem.contentEquals(newItem)
        }

        override fun areContentsTheSame(oldItem: LogEntity, newItem: LogEntity): Boolean {
            return oldItem.contentEquals(newItem)
        }
    }

    val differ = AsyncListDiffer(this, differCallBack)
    inner class LogCycleViewHolder(private val binding: LogCycleItemBinding) :
        RecyclerView.ViewHolder(binding.root) {

        fun bindView(logItem: LogEntity) {
            binding.apply {
                title.text = logItem.name
                insertGram.transformationMethod = null
                insertGram.hint = "${insertGram.hint} ${logItem.measure}"
            }
        }

        fun getValue(): Int? {
            if(!binding.insertGram.text.isEmpty()) {
                val input = binding.insertGram.text.toString();
                try {
                    return input.toInt()
                } catch (e: NumberFormatException) {
                    return null
                }
            }
            return null
        }

    }

    fun submitList(list: List<LogEntity>){
        val list1 : MutableList<LogEntity> = mutableListOf();
        for (entity in list){
            if (entity.inLogCycle){
                list1.add(entity)
            }
        }
        differ.submitList(list1)
    }


    override fun getItemCount(): Int {
        return differ.currentList.size

    }

    fun retrieveViewHolders(): MutableList<LogCycleViewHolder>{
        return viewHolderList

    }

}