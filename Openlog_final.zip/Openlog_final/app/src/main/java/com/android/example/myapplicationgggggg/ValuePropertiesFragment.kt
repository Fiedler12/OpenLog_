package com.android.example.myapplicationgggggg

import android.annotation.SuppressLint
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels
import androidx.navigation.fragment.findNavController
import androidx.navigation.fragment.navArgs
import com.android.example.myapplicationgggggg.databinding.ValuePropertiesFragmentBinding
import com.android.example.myapplicationgggggg.recycler.ValueViewModel
import com.android.example.myapplicationgggggg.recycler.ValueViewModelFactory

class ValuePropertiesFragment : Fragment() {
    private val viewModel: ValueViewModel by activityViewModels {
        ValueViewModelFactory(
            (activity?.application as OpenLogApp).valueDatabase.valueDao()
        )
    }

    private var _binding: ValuePropertiesFragmentBinding? = null
    private val binding get() = _binding!!
    private val navigationArgs : ValuePropertiesFragmentArgs by navArgs()

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        _binding = ValuePropertiesFragmentBinding.inflate(inflater, container, false)
        return binding.root
    }

    @SuppressLint("SetTextI18n")
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        binding.apply {
            logName.text = "${getString(R.string.logname)} ${navigationArgs.logName}"
            value.text = "${getString(R.string.value)} ${navigationArgs.valueentity.value}"
            date.text = "${getString(R.string.value)} ${navigationArgs.valueentity.date}"
            changeValue.transformationMethod = null

        }
        binding.changeButton.setOnClickListener {
            if (!binding.changeValue.text.isEmpty()) {
                var valueEntity = navigationArgs.valueentity
                val input = binding.changeValue.text.toString();
                try {
                    valueEntity.value = binding.changeValue.text.toString().toInt()
                    viewModel.updateValue(valueEntity)
                    val action = ValuePropertiesFragmentDirections.actionValuePropertiesFragmentToOverviewFragment(navigationArgs.logName, navigationArgs.valueentity.logId, navigationArgs.measure, navigationArgs.currentLog)
                    findNavController().navigate(action)

                }
                catch (e: NumberFormatException) {
                    null
                }
            }
        }

        binding.deleteButton.setOnClickListener {
            viewModel.deleteSingleValue(navigationArgs.valueentity)
            val action = ValuePropertiesFragmentDirections.actionValuePropertiesFragmentToOverviewFragment(navigationArgs.logName, navigationArgs.valueentity.logId, navigationArgs.measure, navigationArgs.currentLog)
            findNavController().navigate(action)
        }
        binding.backButton.setOnClickListener {
            val action = ValuePropertiesFragmentDirections.actionValuePropertiesFragmentToOverviewFragment(navigationArgs.logName, navigationArgs.valueentity.logId, navigationArgs.measure, navigationArgs.currentLog)
            findNavController().navigate(action)
        }
    }
}