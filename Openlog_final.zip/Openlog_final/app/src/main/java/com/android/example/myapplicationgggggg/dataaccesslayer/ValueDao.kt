package com.android.example.myapplicationgggggg.dataaccesslayer

import androidx.lifecycle.LiveData
import androidx.room.*

/**
 * Made by Oliver Fiedler s204523
 */
@Dao
interface ValueDao {

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insert(valueEntity: ValueEntity)

    @Update
    suspend fun update(valueEntity: ValueEntity)

    @Delete
    suspend fun delete(valueEntity: ValueEntity)

    @Query ("SELECT * from value WHERE logId = :id")
    fun getValues(id: Int): LiveData<List<ValueEntity>>
}