package com.android.example.myapplicationgggggg

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.fragment.app.activityViewModels
import androidx.navigation.fragment.findNavController
import androidx.navigation.fragment.navArgs
import com.android.example.myapplicationgggggg.dataaccesslayer.ValueEntity
import com.android.example.myapplicationgggggg.databinding.FragmentSingleBinding
import com.android.example.myapplicationgggggg.recycler.ValueViewModel
import com.android.example.myapplicationgggggg.recycler.ValueViewModelFactory
import kotlinx.coroutines.InternalCoroutinesApi
import java.util.*
import android.Manifest


private const val ARG_PARAM1 = "param1"
private const val ARG_PARAM2 = "param2"

const val REQUEST_CODE =200

 class FragmentSingle : Fragment() {


     @OptIn(InternalCoroutinesApi::class)
    private val viewModel: ValueViewModel by activityViewModels {
        ValueViewModelFactory(
            (activity?.application as OpenLogApp).valueDatabase.valueDao()
        )
    }
    lateinit var valueEntity: ValueEntity

    private val navigationArgs: FragmentSingleArgs by navArgs()

    private var _binding: FragmentSingleBinding? = null
    private val binding get() = _binding!!
    private val RQ_SPEECH_REC = 102
    private var micPermission = arrayOf(Manifest.permission.RECORD_AUDIO)
    private var micPermissionGranted = false

    private val permissionLauncher = registerForActivityResult(
         ActivityResultContracts.RequestPermission()
     ) { isGranted ->
         if (isGranted) {
             Toast.makeText(context, "Granted", Toast.LENGTH_SHORT).show()   // Do if the permission is granted
             askSpeechInput()
         }
         else {
             Toast.makeText(context, "Not Granted", Toast.LENGTH_SHORT).show() // Do otherwise
         }
     }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        _binding = FragmentSingleBinding.inflate(inflater, container, false)
        binding.blodinput.transformationMethod = null
        binding.talksugar.setOnClickListener {
           // micPermissionGranted = ActivityCompat.checkSelfPermission(requireContext(), micPermission[0]) == PackageManager.PERMISSION_GRANTED

            //if (!micPermissionGranted) {

                permissionLauncher.launch(Manifest.permission.RECORD_AUDIO)

            //}
        }
        return binding.root
    }

             override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)

        if (requestCode == RQ_SPEECH_REC && resultCode == Activity.RESULT_OK) {
            val result = data?.getStringArrayExtra(RecognizerIntent.EXTRA_RESULTS)
            binding.blodinput.setText(result?.get(0).toString())
        }
    }

     private fun askSpeechInput() {

         val speechRecognizer = requireContext()
        if (!SpeechRecognizer.isRecognitionAvailable(requireContext())) {
            Toast.makeText(context, "Stemme indtastning er ikke tilgængelig", Toast.LENGTH_SHORT)
                .show()
        } else {
            Toast.makeText(context, "Stemmeindtastning er tilgængelig", Toast.LENGTH_SHORT).show()
            val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
            i.putExtra(
                RecognizerIntent.EXTRA_LANGUAGE_MODEL,
                RecognizerIntent.LANGUAGE_MODEL_FREE_FORM
            )
            i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault())
            i.putExtra(RecognizerIntent.EXTRA_PROMPT, "Intast værdi")


        }
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        binding.apply {
            textviewFirst.text = navigationArgs.logName
            blodinput.hint = "${blodinput.hint} " + navigationArgs.logMeasure
        }

        binding.nextpage.setOnClickListener {
            if (!binding.blodinput.text.isEmpty()) {
                addNewValue()
            }
        }
        binding.SingleBackButton.setOnClickListener {
            findNavController().navigate(R.id.action_fragmentSingle_to_FrontpageFragment)
        }

    }
    private fun addNewValue() {
        val input = binding.blodinput.text.toString();
        val a: Int? = try {
            input.toInt()

        }
        catch (e: NumberFormatException) {
          return
        }
        viewModel.addNewValue(a!!, navigationArgs.id)
        findNavController().navigate(R.id.action_fragmentSingle_to_FrontpageFragment)
    }
}