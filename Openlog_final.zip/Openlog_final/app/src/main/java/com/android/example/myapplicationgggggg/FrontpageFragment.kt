package com.android.example.myapplicationgggggg

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.activityViewModels
import androidx.navigation.fragment.findNavController
import androidx.recyclerview.widget.LinearLayoutManager
import com.android.example.basicapp.recycler.CustomAdapter
import com.android.example.myapplicationgggggg.databinding.FragmentOpenlogBinding
import com.android.example.myapplicationgggggg.recycler.LogViewModel
import com.android.example.myapplicationgggggg.recycler.LogViewModelFactory
import kotlinx.coroutines.InternalCoroutinesApi

@InternalCoroutinesApi
class FrontpageFragment : Fragment() {
    @InternalCoroutinesApi
    private val viewModel: LogViewModel by activityViewModels {
        LogViewModelFactory(
            (activity?.application as OpenLogApp).logDatabase.logDao()
        )
    }

    private var _binding: FragmentOpenlogBinding? = null
    private val binding get() = _binding!!

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        _binding = FragmentOpenlogBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        binding.logCycleButton.setOnClickListener {
            findNavController().navigate(R.id.action_FrontpageFragment_to_logcycle)
        }

        binding.fab.setOnClickListener {
            addNewLog()
        }

        val adapter = CustomAdapter()

        binding.recyclerView.layoutManager = LinearLayoutManager(this.context)
        binding.recyclerView.adapter = adapter
        viewModel.allLogs.observe(this.viewLifecycleOwner) { logs ->
            logs.let {
                adapter.differ.submitList(it)
            }
        }
        binding.helpButton.setOnClickListener(){
            Toast.makeText(context,getString(R.string.help_btn),Toast.LENGTH_LONG).show()
        }
    }

    private fun addNewLog() {
        findNavController().navigate(R.id.action_frontpageFragment_to_addLogFragment)
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }

}