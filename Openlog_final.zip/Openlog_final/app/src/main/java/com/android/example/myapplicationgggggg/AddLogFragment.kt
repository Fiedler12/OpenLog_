package com.android.example.myapplicationgggggg

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels
import androidx.navigation.fragment.findNavController
import com.android.example.myapplicationgggggg.dataaccesslayer.LogEntity
import com.android.example.myapplicationgggggg.databinding.NewLogFragmentBinding
import com.android.example.myapplicationgggggg.recycler.LogViewModel
import com.android.example.myapplicationgggggg.recycler.LogViewModelFactory
import kotlinx.coroutines.InternalCoroutinesApi

/**
 * Made by Oliver Fiedler s204523
 */
class AddLogFragment : Fragment() {

    @OptIn(InternalCoroutinesApi::class)
    private val viewModel: LogViewModel by activityViewModels {
        LogViewModelFactory(
            (activity?.application as OpenLogApp).logDatabase
            .logDao()
        )
    }

    lateinit var logEntity: LogEntity

    private var _binding: NewLogFragmentBinding? = null
    private val binding get() = _binding!!

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        _binding = NewLogFragmentBinding.inflate(inflater, container, false)
        return binding.root
    }

    private fun bind(logEntity: LogEntity) {
        binding.apply {
            nameInput.setText(logEntity.name, TextView.BufferType.SPANNABLE)
            measureInput.setText(logEntity.measure, TextView.BufferType.SPANNABLE)

        }
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        binding.submitButton.setOnClickListener {
            addNewLog()
        }
        binding.backButton.setOnClickListener {
            findNavController().navigate(R.id.action_addLogFragment_to_FrontpageFragment)
        }
    }

    private fun addNewLog() {
        if (!(binding.nameInput.text.isEmpty() && binding.measureInput.text.isEmpty())) {
            viewModel.addNewItem(
                binding.nameInput.text.toString(),
                binding.measureInput.text.toString(),
                binding.switchLogCycle.isChecked()
            )
            findNavController().navigate(R.id.action_addLogFragment_to_FrontpageFragment)
        }
    }
}