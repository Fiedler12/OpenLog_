import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.android.example.myapplicationgggggg.dataaccesslayer.ValueEntity
import com.android.example.myapplicationgggggg.databinding.OverviewElementBinding

class OverviewAdapter(private val onItemClicked: (ValueEntity) -> Unit) :
        ListAdapter<ValueEntity, OverviewAdapter.ValueViewHolder>(DiffCallback) {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ValueViewHolder {
        return ValueViewHolder(
            OverviewElementBinding.inflate(
                LayoutInflater.from(
                    parent.context
                )
            )
        )
    }

    override fun onBindViewHolder(holder: ValueViewHolder, position: Int) {
        val current = getItem(position)
        holder.itemView.setOnClickListener {
            onItemClicked(current)
        }
        holder.bind(current)
    }

    class ValueViewHolder(private var binding: OverviewElementBinding) :
        RecyclerView.ViewHolder(binding.root) {
        fun bind(valueEntity: ValueEntity) {
            binding.value.text = valueEntity.value.toString()
            binding.date.text = valueEntity.date
            binding.time.text = valueEntity.time
        }
        }

    companion object {
        private val DiffCallback = object : DiffUtil.ItemCallback<ValueEntity>() {
            override fun areItemsTheSame(oldItem: ValueEntity, newItem: ValueEntity): Boolean {
                return oldItem === newItem
            }

            override fun areContentsTheSame(oldItem: ValueEntity, newItem: ValueEntity): Boolean {
                return oldItem.value == newItem.value
            }
        }
    }
}