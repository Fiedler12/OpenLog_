package com.android.example.myapplicationgggggg

import OverviewAdapter
import android.app.AlertDialog
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.*
import androidx.navigation.fragment.findNavController
import androidx.navigation.fragment.navArgs
import androidx.recyclerview.widget.LinearLayoutManager
import com.android.example.myapplicationgggggg.databinding.FragmentOverviewBinding
import com.android.example.myapplicationgggggg.recycler.LogViewModel
import com.android.example.myapplicationgggggg.recycler.LogViewModelFactory
import com.android.example.myapplicationgggggg.recycler.ValueViewModel
import com.android.example.myapplicationgggggg.recycler.ValueViewModelFactory
import kotlinx.coroutines.InternalCoroutinesApi

class OverviewFragment: Fragment() {

    @OptIn(InternalCoroutinesApi::class)
    private val logViewModel: LogViewModel by activityViewModels {
        LogViewModelFactory(
            (activity?.application as OpenLogApp).logDatabase.logDao()
        )
    }

    @OptIn(InternalCoroutinesApi::class)
    private val viewModel: ValueViewModel by activityViewModels {
        ValueViewModelFactory(
            (activity?.application as OpenLogApp).valueDatabase.valueDao()
        )
    }

    private var _binding: FragmentOverviewBinding? = null
    private val binding get() = _binding!!
    private val navigationArgs: OverviewFragmentArgs by navArgs()

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        _binding = FragmentOverviewBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        val deleteDialog = AlertDialog.Builder(this.context)
            .setTitle(getString(R.string.are_you_sure))
            .setMessage(getString(R.string.sure_delete))
            .setPositiveButton(getString(R.string.yes)) { _, _ ->
                deleteLog()
            }
            .setNegativeButton(getString(R.string.no)) {_, _ ->
            }.create()

        binding.title.text = navigationArgs.logTitle
        binding.measure.text = navigationArgs.measure
        binding.checkBox.isChecked = navigationArgs.currentLog.inLogCycle


        val adapter = OverviewAdapter {
            val action = OverviewFragmentDirections.actionOverviewFragmentToValuePropertiesFragment(it, navigationArgs.logTitle, navigationArgs.measure, navigationArgs.currentLog)
            findNavController().navigate(action)
        }
        binding.overviewrecycler.layoutManager = LinearLayoutManager(this.context)
        binding.overviewrecycler.adapter = adapter

        viewModel.getValues(navigationArgs.logId).observe(this.viewLifecycleOwner) { items ->
            items.let {
                adapter.submitList(it)
            }
    }
        binding.backButton.setOnClickListener {
            logViewModel.updateLog(navigationArgs.currentLog)
            findNavController().navigate(OverviewFragmentDirections.actionOverviewFragmentToFrontpageFragment()) }
        binding.deleteButton.setOnClickListener {
            deleteDialog.show()
        }

        binding.checkBox.textOn = getString(R.string.inLogCycle)
        binding.checkBox.textOff = getString(R.string.notInLogCycle)

        binding.checkBox.setOnCheckedChangeListener {buttonView, isChecked ->
            navigationArgs.currentLog.inLogCycle = buttonView.isChecked
        }
    }

    fun deleteLog() {
        logViewModel.removeLog(navigationArgs.currentLog)
        findNavController().navigate(OverviewFragmentDirections.actionOverviewFragmentToFrontpageFragment())
    }
}
