package com.android.example.myapplicationgggggg.dataaccesslayer

import android.os.Parcelable
import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey
import kotlinx.android.parcel.Parcelize

/**
 * Made by Oliver Fiedler s204523
 */
@Parcelize
@Entity(tableName = "value")
data class ValueEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Int = 0,
    @ColumnInfo(name = "logId")
    val logId: Int,
    @ColumnInfo(name = "value")
    var value: Int,
    @ColumnInfo(name = "date")
    val date: String,
    @ColumnInfo(name = "time")
    val time: String
) : Parcelable