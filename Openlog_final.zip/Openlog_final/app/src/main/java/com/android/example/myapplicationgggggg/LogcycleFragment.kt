package com.android.example.myapplicationgggggg

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.activityViewModels
import androidx.navigation.fragment.findNavController
import androidx.recyclerview.widget.LinearLayoutManager
import com.android.example.myapplicationgggggg.databinding.LogCycleFragmentBinding
import com.android.example.myapplicationgggggg.recycler.*
import kotlinx.coroutines.InternalCoroutinesApi

// TODO: Rename parameter arguments, choose names that match
// the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
private const val ARG_PARAM1 = "param1"
private const val ARG_PARAM2 = "param2"

/**
 * A simple [Fragment] subclass.
 * Use the [LogcycleFragment.newInstance] factory method to
 * create an instance of this fragment.
 */
@InternalCoroutinesApi
class LogcycleFragment : Fragment() {

    @InternalCoroutinesApi
    private val viewModel: LogViewModel by activityViewModels {
        LogViewModelFactory(
            (activity?.application as OpenLogApp).logDatabase.logDao()
        )
    }

    @OptIn(InternalCoroutinesApi::class)
    private val valueViewModel: ValueViewModel by activityViewModels {
        ValueViewModelFactory(
            (activity?.application as OpenLogApp).valueDatabase.valueDao()
        )
    }


    private var _binding: LogCycleFragmentBinding? = null
    private val binding get() = _binding!!

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {

        _binding = LogCycleFragmentBinding.inflate(inflater, container, false)
        return binding.root

    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val adapter = LogCycleAdapter()

        binding.logCycleRecyclerview.layoutManager = LinearLayoutManager(this.context)
        binding.logCycleRecyclerview.adapter = adapter

        viewModel.allLogs.observe(this.viewLifecycleOwner){ logs ->
            logs.let{
                adapter.submitList(it)
            }
        }

        binding.submitButton.setOnClickListener {
            val list: MutableList<LogCycleAdapter.LogCycleViewHolder> = adapter.retrieveViewHolders()
            var i = 0
            for (holder in list){

                val readVal = holder.getValue()
                if(readVal != null) {
                    valueViewModel.addNewValue(readVal,  adapter.differ.currentList.get(i).id)
                }
                i++
            }
            findNavController().navigate(R.id.action_log_cycle_to_FrontpageFragment)

        }
        binding.backButton.setOnClickListener {
            findNavController().navigate(R.id.action_log_cycle_to_FrontpageFragment)
        }
    }
}