package com.android.example.myapplicationgggggg.dataaccesslayer

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

/**
 * Made by Oliver Fiedler s204523
 */
@Database(entities = [LogEntity::class], version = 3, exportSchema = false)
abstract class LogDatabase : RoomDatabase() {
    abstract fun logDao(): LogDao

    companion object {
        @Volatile
        private var INSTANCE: LogDatabase? = null
        fun getDatabase(context: Context): LogDatabase {
            return INSTANCE ?: synchronized(this) {
            val instance = Room.databaseBuilder(
                context.applicationContext,
                LogDatabase::class.java,
                "log_database"
            )
                .fallbackToDestructiveMigration()
                .build()
            INSTANCE = instance
            return instance
        }}

    }
}