package com.android.example.myapplicationgggggg.dataaccesslayer

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

/**
 * Made by Oliver Fiedler s204523
 */
@Database(entities = [ValueEntity::class], version = 3, exportSchema = false)
abstract class ValueDatabase : RoomDatabase() {
    abstract fun valueDao(): ValueDao
    companion object {
        @Volatile
        private var INSTANCE: ValueDatabase? = null
        fun getDatabase(context: Context): ValueDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    ValueDatabase::class.java,
                    "value_database"
                )
                    .fallbackToDestructiveMigration()
                    .build()
                INSTANCE = instance
                return instance
            }
        }
    }
}